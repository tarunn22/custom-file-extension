# SPDX-FileCopyrightText: 2023-present Dynatrace LLC
#
# SPDX-License-Identifier: MIT

import logging
import random
import time
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from timeit import default_timer as timer

from .activation import ActivationType
from .status import EndpointStatuses, IgnoreStatus, MultiStatus, Status, StatusValue


class WrappedCallback:
    def __init__(
        self,
        interval: timedelta,
        callback: Callable,
        logger: logging.Logger,
        args: tuple | None = None,
        kwargs: dict | None = None,
        running_in_sim=False,
        activation_type: ActivationType | None = None,
        offset_seconds: float | None = None,
    ):
        self.callback: Callable = callback
        if args is None:
            args = ()
        self.callback_args = args
        if kwargs is None:
            kwargs = {}
        self.callback_kwargs = kwargs
        self.interval: timedelta = interval
        self.logger = logger
        self.running: bool = False
        self.status = Status(StatusValue.OK)
        self.executions_total = 0  # global counter, counts actual callback executions
        self.executions_per_interval = 0  # counter per interval = 1 min by default
        self.duration = 0  # global counter
        self.duration_interval_total = 0  # counter per interval = 1 min by default
        self.cluster_time_diff = 0
        self.start_timestamp_monotonic = time.monotonic()
        self.start_timestamp = self.get_current_time_with_cluster_diff()
        self.running_in_sim = running_in_sim
        self.activation_type = activation_type
        self.ok_count = 0  # counter per interval = 1 min by default
        self.timeouts_count = 0  # counter per interval = 1 min by default
        self.exception_count = 0  # counter per interval = 1 min by default
        self.iterations = 0  # how many times we ran the callback iterator for this callback
        self.scheduled_iteration_snapshot = 0  # snapshot of `iterations` taken at the start of each execution
        self.offset_seconds = offset_seconds or self.calculate_initial_wait_time()

    def get_current_time_with_cluster_diff(self):
        return datetime.now(timezone.utc) + timedelta(milliseconds=self.cluster_time_diff)

    def __call__(self):
        self.logger.debug(f"Running scheduled callback {self}")
        self.running = True
        self.executions_total += 1
        self.executions_per_interval += 1
        # Snapshot the scheduler tick index so all metrics emitted during this
        # execution share one timestamp bucket, even if the next scheduler tick
        # fires while we are still running.
        self.scheduled_iteration_snapshot = self.iterations
        start_time = timer()
        failed = False
        try:
            ret = self.callback(*self.callback_args, **self.callback_kwargs)
            if isinstance(ret, Status):
                self.status = ret
            elif isinstance(ret, MultiStatus):
                self.status = ret.build()
            elif isinstance(ret, EndpointStatuses):
                self.status = ret
            elif isinstance(ret, IgnoreStatus):
                self.status = ret
            else:
                self.status = Status(StatusValue.OK)
        except Exception as e:
            failed = True
            self.logger.exception(f"Error running callback {self}: {e!r}")
            self.status = Status(StatusValue.GENERIC_ERROR, repr(e))
            self.exception_count += 1

        self.running = False
        self.duration = timer() - start_time
        self.duration_interval_total += self.duration
        self.logger.debug(f"Ran scheduled callback {self} in {self.duration:.2f} seconds")
        if self.duration > self.interval.total_seconds():
            message = f"Callback {self} took {self.duration:.4f} seconds to execute, which is longer than the interval of {self.interval.total_seconds()}s"
            self.logger.warning(message)
            self.status = Status(StatusValue.GENERIC_ERROR, message)
            self.timeouts_count += 1
        elif not failed:
            self.ok_count += 1

    def __repr__(self):
        return f"Method={self.callback.__name__}"

    def name(self):
        return self.callback.__name__

    def calculate_initial_wait_time(self) -> float:
        """
        Here we chose a random second between 5 and 55 to start the callback
        This is to distribute load for extension running on this host
        """

        now = self.get_current_time_with_cluster_diff()
        random_second = random.randint(5, 55)  # noqa: S311
        next_execution = now.replace(second=random_second, microsecond=0)
        if next_execution <= now:
            # The random chosen second already passed this minute
            next_execution += timedelta(minutes=1)
        wait_time = (next_execution - now).total_seconds()
        self.logger.debug(f"Randomly choosing next execution time for callback {self} to be {next_execution}")
        return wait_time

    def initial_wait_time(self) -> float:
        # When running from the simulator, we don't want any offset
        if self.running_in_sim:
            return 0

        return self.offset_seconds

    def get_adjusted_metric_timestamp(self) -> datetime:
        """
        Callbacks can't run all together, so they must start at random times
        This means that when reporting metrics for a callback, we need to consider
        the time the callback was started, instead of the current timestamp
        this is done to avoid situations like:
        - 14:00:55 - callback A runs
        - 14:01:03 - 8 seconds later, a metric is reported
        - 14:01:55 - callback A runs again (60 seconds after the first run)
        - 14:01:58 - 3 seconds later a metric is reported
        In this scenario a metric is reported twice in the same minute
        This can also cause minutes where a metric is not reported at all, creating gaps

        The metric timestamp is derived from the callback's start time and the
        scheduler tick index snapshotted at the start of this execution:
        start_timestamp + (scheduled_iteration_snapshot - 1) * interval.

        We use the snapshot (taken in __call__) rather than the live `iterations`
        counter so that all metrics emitted during one execution share one
        timestamp bucket, even if the scheduler fires the next tick (bumping
        `iterations`) while this run is still in progress.
        """
        return self.start_timestamp + timedelta(
            seconds=self.interval.total_seconds() * max(self.scheduled_iteration_snapshot - 1, 0)
        )

    def clear_sfm_metrics(self):
        self.ok_count = 0
        self.timeouts_count = 0
        self.duration_interval_total = 0
        self.exception_count = 0
        self.executions_per_interval = 0

    def get_next_execution_timestamp(self) -> float:
        """
        Get the timestamp for the next execution of the callback
        This is done using execution total, the interval and the start timestamp
        :return: float
        """
        return (
            self.initial_wait_time()
            + self.start_timestamp_monotonic
            + self.interval.total_seconds() * (self.iterations or 1)
        )
